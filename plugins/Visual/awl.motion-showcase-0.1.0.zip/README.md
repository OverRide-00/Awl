# Awl Motion Showcase

A Visual plugin based on `motion-showcase.html`, using **Awl Motion API** for frame scheduling and procedural curves. It contains no executable code, actions, or new tabs.

Install and enable Awl Motion API first, then install this package from Config. It can be enabled or disabled without restarting Awl. With the API missing or disabled, Awl keeps its standard motion instead.

- Start opens at the taskbar's width and position, rises into the screen center in 280ms, and reshapes its blank shell to the configured menu size. The UI fades in only once the shell has settled, at its normal proportions. Side/top taskbars and a Start menu on another monitor are supported.
- Taskbar hover lifts/scales the icon with a small spring overshoot, independently of the old Magnify switch. Icons use a transparent overlay so the taskbar window cannot clip their motion.
- A newly opened application's taskbar icon bounces and tilts. Clicking an existing taskbar app also gives that feedback.
- Quick Search starts as a magnifier; a circle grows behind it, stretches into the bar, then the tool buttons drop into place. Typing interrupts the reveal immediately. Dismissal keeps the short scale/fade exit.
- Start closes with a short fade. Escape, focus loss, and repeated toggles clean up in-flight animation.

All effects respect Awl's animation speed, animation-off/reduce-motion settings, and independent surface GUI scaling. Hover is controlled by this plugin, independently of Magnify. The profile does not introduce a search backdrop, preserving the current search UI and opacity settings.

`motion.json` controls durations, hover size/lift, and bounce/tilt. Images `0.png` and `1.png` are schematic previews, not screenshots.

Native app openings and taskbar activation grow a live DWM thumbnail from the icon to the application's existing bounds in 340ms. The real window's geometry stays intact and its temporary cloak is undone at completion, cancellation, failure, shutdown, or by Awl's guard after an unexpected exit. If the compositor rejects an app, Awl keeps the normal activation. Tooltips use a bubble above the taskbar, with a pointer to the app.

Application order holds for one second after activation or opening. The plugin then slides the promoted app into the first slot while the others shift aside. New apps initially enter at the end, so the opening bounce can finish before promotion. Focus/show event hooks refresh the taskbar promptly, and switching back to the first app cancels stale pending moves.

Capture and recorder bars reuse the previous Quick Search 92% spring/fade entrance. Topbar popups (Wi-Fi, Bluetooth, Volume, Microphone, Brightness, Battery, and Notifications) use a top-anchored spring and fade. These effects are independently selectable in motion.json.

App icons land from the main bounce, then make three progressively smaller, faster rebounds before settling.
